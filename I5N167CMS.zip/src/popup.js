document.addEventListener('DOMContentLoaded', function () {
    console.log('doing nothing on DOMContentLoaded');
});
